package utils;

public interface MessageTypes {

    public static int JOIN = 0;
    public static int LEAVE = 1;
    public static int NOTE = 2;
}
